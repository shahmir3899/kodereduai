import{j as o,an as t}from"./financeQueryRules-edDyyKKn.js";function s(){return o.jsx(t,{})}export{s as N};
