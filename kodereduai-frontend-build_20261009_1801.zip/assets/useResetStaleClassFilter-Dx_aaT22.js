import{r as t}from"./financeQueryRules-edDyyKKn.js";function a(r,f,e,u=!1){t.useEffect(()=>{!r||u||!(e!=null&&e.length)||e.some(m=>String(m.id)===String(r))||f("")},[r,f,e,u])}export{a as u};
