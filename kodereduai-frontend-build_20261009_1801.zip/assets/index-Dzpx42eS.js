import{ao as a,am as r}from"./financeQueryRules-edDyyKKn.js";var o=a();const e=r(o);export{e as R,o as r};
