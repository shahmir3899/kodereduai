import{a8 as a,a7 as r}from"./index-DlAEwifa.js";var t=a();const e=r(t);export{e as R,t as r};
