import{j as i}from"./index-DlAEwifa.js";function d({children:r,className:s=""}){return i.jsx("div",{className:`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 ${s}`,children:r})}export{d as C};
